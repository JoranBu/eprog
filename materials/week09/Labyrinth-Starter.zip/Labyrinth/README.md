# Labyrinth - Woche 9

Starter ohne Loesungen: Implementiere `task1` und `task2` in `src/main/java/Labyrinth.java`.
`Room.java` entspricht der Vorlage. Die Grundaufgabe nimmt ein gerichtetes, zyklenfreies Labyrinth an.

## IntelliJ IDEA
1. ZIP vollstaendig entpacken und den Ordner `Labyrinth` ueber File > Open oeffnen.
2. Als Gradle-Projekt importieren und den enthaltenen Gradle Wrapper verwenden.
3. Ein JDK 17 bis 25 als Project SDK und Gradle JVM einstellen (z.B. JDK 21).
4. Gradle synchronisieren, dann `Main.main()` oder die Gradle-Aufgabe `run` starten.

Ein installiertes JDK und Internet beim ersten Start sind erforderlich. Gradle 9.1.0 wird automatisch heruntergeladen; Gradle muss nicht separat installiert werden.

## Terminal
Windows: ` .\gradlew.bat run`
macOS/Linux: `chmod +x gradlew`, danach `./gradlew run`
Kompilieren: `./gradlew build` (Windows: `.\gradlew.bat build`).
Beispieltests: `./gradlew examples` (Windows: `.\gradlew.bat examples`).

`Main` zeigt Ergebnisse und Erwartungswerte. Die TODO-Methoden liefern anfangs immer false.
Die Beispieltests in `src/test/java/LabyrinthTest.java` sind eigens erstellte, nicht vollstaendige Tests, nicht die offiziellen Kurstests. Einige schlagen absichtlich fehl, solange die Aufgaben nicht implementiert sind. `build` prueft nur, ob der Starter kompiliert; die Beispieltests werden separat mit `examples` ausgefuehrt.

Die Aufgabenstellung liegt als PDF auf der Webseite bei Woche 9.
