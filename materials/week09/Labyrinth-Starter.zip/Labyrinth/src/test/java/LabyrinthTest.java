// Eigene Beispieltests zur Vorlage, nicht die offiziellen Kurstests.
public class LabyrinthTest {
    private static int failures;
    private static void check(String name, boolean expected, boolean actual) {
        System.out.println((expected == actual ? "OK   " : "FAIL ") + name);
        if (expected != actual) failures++;
    }
    public static void main(String[] args) {
        Room exit = new Room(1, new Room[0]);
        check("task1: einzelner Ausgang", true, Labyrinth.task1(exit));
        check("task1: Alter null", false, Labyrinth.task1(new Room(0, new Room[0])));
        check("task1: ungueltiger Praefix", false, Labyrinth.task1(new Room(2, new Room[]{exit})));
        check("task2: nur ein Pfad", false, Labyrinth.task2(exit));
        Room fork = new Room(1, new Room[]{new Room(1, new Room[0]), new Room(1, new Room[0])});
        check("task2: gleiche Altersfolge", true, Labyrinth.task2(fork));
        Room merge = new Room(1, new Room[]{new Room(2, new Room[]{exit}), new Room(2, new Room[]{exit})});
        check("task2: wieder zusammenlaufende Pfade", true, Labyrinth.task2(merge));
        check("task2: dieselbe Referenz zweimal", false, Labyrinth.task2(new Room(1, new Room[]{exit, exit})));
        if (failures > 0) throw new AssertionError(failures + " Beispieltests fehlgeschlagen. TODOs implementieren.");
    }
}
