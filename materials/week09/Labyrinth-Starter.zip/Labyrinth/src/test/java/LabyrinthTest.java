// Eigene Beispieltests, nicht die offiziellen Kurstests.
// Ausfuehren: ./gradlew examples (Windows: .\\gradlew.bat examples)
public class LabyrinthTest {
    private static int total;
    private static int failures;

    private static Room room(int age, Room... doors) {
        return new Room(age, doors);
    }

    // Baut eine lineare Kette; der letzte Raum ist der Ausgang.
    private static Room path(int... ages) {
        Room current = room(ages[ages.length - 1]);
        for (int i = ages.length - 2; i >= 0; i--) {
            current = room(ages[i], current);
        }
        return current;
    }

    private static void check(String name, int task, Room start, boolean expected) {
        total++;
        try {
            boolean actual = task == 1 ? Labyrinth.task1(start) : Labyrinth.task2(start);
            if (actual != expected) failures++;
            System.out.println((actual == expected ? "OK   " : "FAIL ") + name
                    + " | erwartet: " + expected + ", erhalten: " + actual);
        } catch (RuntimeException | StackOverflowError e) {
            failures++;
            System.out.println("FAIL " + name + " | " + e);
        }
    }

    private static void task1Examples() {
        System.out.println("\nAufgabe 1: Jede Praefixsumme muss nicht durch 3 teilbar sein.");
        check("Einzelner Ausgang, Alter 1", 1, room(1), true);
        check("Einzelner Ausgang, Alter 0", 1, room(0), false);
        check("Einzelner Ausgang, Alter 6", 1, room(6), false);
        check("Ungueltiger Start trotz gueltiger Gesamtsumme", 1, path(3, 1), false);
        check("Ungueltiger mittlerer Praefix", 1, path(1, 2, 1), false);
        check("Erst am Ausgang ungueltig", 1, path(1, 1, 1), false);
        check("Alter 0 innerhalb eines gueltigen Pfads", 1, path(1, 0, 3, 0, 3), true);
        check("Nur Praefixe, nicht beliebige Teilstuecke", 1, path(1, 3, 3), true);
        check("Erster Zweig falsch, zweiter richtig", 1, room(1, room(2), path(1, 3, 3)), true);
        check("Alle Zweige falsch", 1, room(1, room(2), path(1, 1)), false);

        // Derselbe Raum wird mit unterschiedlichen bisherigen Summen erreicht.
        Room shared = room(1);
        Room branches = room(1, room(1, shared), room(3, shared));
        check("Gemeinsamer Raum, anderer Praefix", 1, branches, true);
        check("Wiederholter Aufruf auf denselben Objekten", 1, branches, true);

        // 121 Raeume: Praefixsummen 1, 4, 7, ..., 361.
        int[] ages = new int[121];
        ages[0] = 1;
        for (int i = 1; i < ages.length; i++) ages[i] = 3;
        check("Langer gueltiger Pfad (121 Raeume)", 1, path(ages), true);
        ages[ages.length - 1] = 2;
        check("Langer Pfad, letzter Praefix ungueltig", 1, path(ages), false);
    }

    private static void task2Examples() {
        System.out.println("\nAufgabe 2: Zwei verschiedene Pfade mit identischer Altersfolge.");
        check("Ein Ausgang ist nur ein Pfad", 2, room(1), false);
        check("Eine lange Kette ist nur ein Pfad", 2, path(1, 2, 3, 4, 5, 6), false);
        check("Zwei verschiedene Ausgaenge, gleiches Alter", 2, room(1, room(2), room(2)), true);
        check("Unterschiedliche Ausgangsalter", 2, room(1, room(2), room(3)), false);
        check("Gleiche Alter, unterschiedliche Pfadlaenge", 2, room(1, room(2), path(2, 2)), false);
        check("Gleiche Summe reicht nicht", 2, room(1, path(2, 4), path(3, 3)), false);
        check("Teilbarkeit durch 3 ist hier irrelevant", 2, room(0, path(3, 6), path(3, 6)), true);

        Room exit = room(4);
        check("Verzweigung mit erneutem Zusammenlaufen", 2,
                room(1, room(2, exit), room(2, exit)), true);
        check("Zwei Tueren zur gleichen Referenz sind kein neuer Pfad", 2,
                room(1, exit, exit), false);
        check("Verzweigung erst nach gemeinsamem Anfang", 2,
                room(1, room(2, room(3, room(4), room(4)))), true);
        check("Passendes Paar erst unter spaeteren Zweigen", 2,
                room(1, path(9, 8), path(2, 3), path(2, 3)), true);

        Room longFork = room(1, path(2, 3, 4, 5, 6, 7, 8, 9),
                path(2, 3, 4, 5, 6, 7, 8, 9));
        check("Zwei lange gleiche Altersfolgen", 2, longFork, true);
        check("Wiederholter Aufruf auf denselben Objekten", 2, longFork, true);
        check("Unterschied erst tief im Labyrinth", 2,
                room(1, path(2, 3, 4, 5, 6, 7, 8), path(2, 3, 4, 5, 6, 7, 9)), false);
    }

    public static void main(String[] args) {
        task1Examples();
        task2Examples();
        System.out.println("\n" + (total - failures) + "/" + total + " Tests bestanden.");
        if (failures > 0) {
            throw new AssertionError(failures + " Tests fehlgeschlagen. TODOs pruefen.");
        }
    }
}
