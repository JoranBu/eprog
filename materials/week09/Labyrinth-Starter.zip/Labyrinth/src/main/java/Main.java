public class Main {
    public static void main(String[] args) {
        Room exit1 = new Room(1, new Room[0]);
        Room exit2 = new Room(1, new Room[0]);
        Room start = new Room(1, new Room[] {exit1, exit2});
        System.out.println("Labyrinth-Starter: task1 und task2 sind noch TODO.");
        System.out.println("task1: " + Labyrinth.task1(start) + " (erwartet nach Implementierung: true)");
        System.out.println("task2: " + Labyrinth.task2(start) + " (erwartet nach Implementierung: true)");
    }
}
