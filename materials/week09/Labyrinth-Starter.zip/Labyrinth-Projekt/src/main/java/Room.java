public class Room {

    public int age;
    public Room[] doorsTo;

    // PRE: age >= 0; doorsTo and all its elements are non-null.
    public Room(int age, Room... doorsTo) {
        this.age = age;
        this.doorsTo = doorsTo;
    }
}
