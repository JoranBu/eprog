import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;

@Timeout(10)
public class LabyrinthTest {

    @Test
    public void task1SingleExitIncludesItsOwnAge() {
        assertTrue(Labyrinth.task1(new Room(1)));
        assertTrue(Labyrinth.task1(new Room(2)));
        assertFalse(Labyrinth.task1(new Room(0)));
        assertFalse(Labyrinth.task1(new Room(6)));
    }

    @Test
    public void task1AllPrefixSumsMustBeValid() {
        assertTrue(Labyrinth.task1(path(1, 1, 2)));
        assertFalse(Labyrinth.task1(path(1, 2, 1)));
        assertFalse(Labyrinth.task1(path(3, 1)));
        assertFalse(Labyrinth.task1(path(1, 1, 1)));
    }

    @Test
    public void task1ZeroAgeIsAllowedAfterAValidPrefix() {
        assertTrue(Labyrinth.task1(path(1, 0, 0, 1)));
        assertFalse(Labyrinth.task1(path(0, 1, 1)));
    }

    @Test
    public void task1MustAccumulateTheEntirePrefix() {
        assertFalse(Labyrinth.task1(path(1, 1, 1)));
        assertTrue(Labyrinth.task1(path(2, 2, 1)));
    }

    @Test
    public void task1TriesOtherDoorsWithoutLeakingTheSum() {
        Room room = new Room(1, new Room(2), new Room(1, new Room(2)));
        assertTrue(Labyrinth.task1(room));
        room.doorsTo = new Room[] {room.doorsTo[1], room.doorsTo[0]};
        assertTrue(Labyrinth.task1(room));
    }

    @Test
    public void task1ReturnsFalseWhenEveryBranchFails() {
        assertFalse(Labyrinth.task1(new Room(1,
                new Room(2), new Room(1, new Room(1)))));
    }

    @Test
    public void task1SharedRoomDependsOnTheIncomingSum() {
        Room exit = new Room(1);
        Room room = new Room(1, new Room(1, exit), new Room(0, exit));
        assertTrue(Labyrinth.task1(room));
    }

    @Test
    public void task1CanStopBeforeEnumeratingAllPaths() {
        Room room = new Room(1);
        for (int i = 0; i < 40; i++) {
            room = new Room(0, room, room);
        }
        assertTrue(Labyrinth.task1(new Room(1, room)));
    }

    @Test
    public void task2OneRoomOrOnePathIsNotEnough() {
        assertFalse(Labyrinth.task2(new Room(1)));
        assertFalse(Labyrinth.task2(path(1, 2, 3, 4)));
    }

    @Test
    public void task2DistinctExitsWithEqualAgesAreEnough() {
        assertTrue(Labyrinth.task2(new Room(0, new Room(5), new Room(5))));
        assertFalse(Labyrinth.task2(new Room(0, new Room(5), new Room(6))));
    }

    @Test
    public void task2DuplicateDoorsDoNotCreateDistinctRoomPaths() {
        Room exit = new Room(5);
        assertFalse(Labyrinth.task2(new Room(0, exit, exit)));
        Room shared = new Room(2, exit);
        assertFalse(Labyrinth.task2(new Room(0, shared, shared)));
    }

    @Test
    public void task2PathsMaySplitAndMergeAgain() {
        Room exit = new Room(7);
        Room left = new Room(3, exit);
        Room right = new Room(3, exit);
        assertTrue(Labyrinth.task2(new Room(0, left, right)));
    }

    @Test
    public void task2DifferenceMayOccurOnlyAtTheLastRoom() {
        Room shared = new Room(4, new Room(7), new Room(7));
        assertTrue(Labyrinth.task2(new Room(1, shared)));
    }

    @Test
    public void task2SameTotalAgeDoesNotMeanSameAgeSequence() {
        assertFalse(Labyrinth.task2(new Room(0, path(1, 3), path(2, 2))));
    }

    @Test
    public void task2RequiresEqualLengthsAndBothPathsMustReachExits() {
        assertFalse(Labyrinth.task2(new Room(0, new Room(2), path(2, 0))));
        assertFalse(Labyrinth.task2(new Room(0, path(2, 4), path(2, 4, 0))));
    }

    @Test
    public void task2SearchesAllDoorPairings() {
        Room left = new Room(3, new Room(7), new Room(8));
        Room right = new Room(3, new Room(8), new Room(9));
        assertTrue(Labyrinth.task2(new Room(0, left, right)));
    }

    @Test
    public void task2DoesNotApplyTheConditionFromTask1() {
        assertTrue(Labyrinth.task2(new Room(0, path(0, 0), path(0, 0))));
    }

    @Test
    public void task2CanStopBeforeEnumeratingAllPaths() {
        Room room = new Room(1, new Room(5), new Room(5));
        for (int i = 0; i < 40; i++) {
            room = new Room(0, room, room);
        }
        assertTrue(Labyrinth.task2(room));
    }

    @Test
    public void repeatedCallsDoNotDependOnPreviousSearches() {
        Room shared = new Room(1);
        Room room = new Room(1, new Room(1, shared), new Room(0, shared));
        for (int i = 0; i < 3; i++) {
            assertTrue(Labyrinth.task1(room));
            assertFalse(Labyrinth.task2(room));
        }
        Room pair = new Room(1, new Room(1), new Room(1));
        for (int i = 0; i < 3; i++) {
            assertTrue(Labyrinth.task2(pair));
            assertTrue(Labyrinth.task1(pair));
        }
    }

    @Test
    public void smallAcyclicLabyrinthsMatchAnIndependentPathOracle() {
        Random random = new Random(20261107L);
        for (int sample = 0; sample < 250; sample++) {
            Room[] rooms = new Room[8];
            for (int i = rooms.length - 1; i >= 0; i--) {
                int count = i == rooms.length - 1 ? 0 : random.nextInt(4);
                Room[] doors = new Room[count];
                for (int j = 0; j < count; j++) {
                    doors[j] = rooms[i + 1 + random.nextInt(rooms.length - i - 1)];
                }
                rooms[i] = new Room(random.nextInt(8), doors);
            }
            List<List<Room>> paths = new ArrayList<>();
            collectPaths(rooms[0], new ArrayList<>(), paths);
            assertEquals(expectedTask1(paths), Labyrinth.task1(rooms[0]),
                    "task1, sample " + sample);
            assertEquals(expectedTask2(paths), Labyrinth.task2(rooms[0]),
                    "task2, sample " + sample);
        }
    }

    private static Room path(int... ages) {
        Room room = new Room(ages[ages.length - 1]);
        for (int i = ages.length - 2; i >= 0; i--) {
            room = new Room(ages[i], room);
        }
        return room;
    }

    // Enumerate paths only for the small oracle inputs, never for the large tests.
    private static void collectPaths(Room room, List<Room> prefix, List<List<Room>> paths) {
        prefix.add(room);
        if (room.doorsTo.length == 0) {
            paths.add(new ArrayList<>(prefix));
        } else {
            for (Room next : room.doorsTo) {
                collectPaths(next, prefix, paths);
            }
        }
        prefix.remove(prefix.size() - 1);
    }

    private static boolean expectedTask1(List<List<Room>> paths) {
        for (List<Room> path : paths) {
            int sum = 0;
            boolean valid = true;
            for (Room room : path) {
                sum += room.age;
                if (sum % 3 == 0) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                return true;
            }
        }
        return false;
    }

    private static boolean expectedTask2(List<List<Room>> paths) {
        for (int i = 0; i < paths.size(); i++) {
            for (int j = i + 1; j < paths.size(); j++) {
                List<Room> first = paths.get(i);
                List<Room> second = paths.get(j);
                if (first.size() != second.size()) {
                    continue;
                }
                boolean sameAges = true;
                boolean differentRooms = false;
                for (int k = 0; k < first.size(); k++) {
                    sameAges &= first.get(k).age == second.get(k).age;
                    differentRooms |= first.get(k) != second.get(k);
                }
                if (sameAges && differentRooms) {
                    return true;
                }
            }
        }
        return false;
    }
}
