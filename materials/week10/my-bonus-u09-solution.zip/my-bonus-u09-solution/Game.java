import java.util.LinkedList;

public class Game {

    public LinkedList<Human> players = new LinkedList<>(); //it always makes sense to keep all the participants
    public LinkedList<Human> actions = new LinkedList<>();

    void advanceTurn() {
        int size = actions.size(); //it's not trivial to go through a list and change items at the same time
        for (int i = 0; i < size; i++) {
            Human fighter = actions.removeFirst(); //use the linked List as a queue
            if (!fighter.isAlive()) continue; //player dead

            if (fighter.delay > 0) { //decrease delay by one and add to the queue again
                fighter.delay--;
                actions.addLast(fighter);
                continue;
            }

            int pos = fighter.getPosition();

            //Action Logic
            switch (fighter.type) { //switch statement
                case JESTER:
                    break;

                case WARRIOR:
                    if (fighter.currentAction == Action.ATTACK) {
                        for (Human target : players) {
                            if (target.getPosition() == pos - 1 || target.getPosition() == pos + 1) {
                                target.health -= 10; //I also attack dead people :/
                            }
                        }
                    } else {
                        fighter.health -= 5;
                    }
                    break; //is needed in switch statements (or break)

                case CLERIC:
                    if (fighter.currentAction == Action.ATTACK) {
                        for (Human target : players) {
                            if (target.getPosition() == pos - 1 || target.getPosition() == pos + 1) {
                                target.health -= 3;
                            }
                        }
                    } else {
                        for (Human target : players) {
                            if (!target.isAlive()) continue;
                            int absDiff = Math.abs(target.getPosition() - pos);
                            if (absDiff >= 3 && absDiff <= 5) {
                                target.position = pos;
                            };
                        }
                    }
                    break;
            }

            fighter.currentAction = null; //fighter doesn't have an action anymore.
        }
    }

    Human createJester(int health, int position) {
        Human newH = new Human(health, position, Type.JESTER, this); //important - pass this
        players.add(newH);
        return newH;
    }

    Human createWarrior(int health, int position) {
        Human newH = new Human(health, position, Type.WARRIOR, this);
        players.add(newH);
        return newH;
    }

    Human createCleric(int health, int position) {
        Human newH = new Human(health, position, Type.CLERIC, this);
        players.add(newH);
        return newH;
    }
}
