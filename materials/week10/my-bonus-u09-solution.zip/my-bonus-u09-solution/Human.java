public class Human {

    public Type type; //I use this instead of subclasses
    public Game game; //Very important Trick in Eprog!

    public Action currentAction;
    public int delay;

    public int health, position;

    public int getHealth() {
        return health;
    }

    public int getPosition() {
        return position;
    }

    public boolean isAlive() {
        return health > 0;
    }

    public boolean scheduleAction(Action action) {
        if (currentAction != null) return false; //there is already an action
        if (!isAlive()) return false; //player is dead

        currentAction = action;
        game.actions.addLast(this); //here we use the this trick

        //action delay logic:
        delay = 0;
        if (action == Action.SUMMON) {
            if (type == Type.WARRIOR) {
                delay = 1;
            } else if (type == Type.CLERIC) {
                delay = 2;
            }
        }
        return true;
    }

    //Default Constructor
    public Human() {

    }

    //write our own constructors
    public Human(int health, int pos, Type type, Game game) {
        this.health = health;
        this.position = pos;
        this.type = type;
        this.game = game; //very important Eprog Trick
    }
}
