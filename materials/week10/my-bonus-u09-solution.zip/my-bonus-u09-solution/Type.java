public enum Type {
    JESTER, WARRIOR, CLERIC
}
